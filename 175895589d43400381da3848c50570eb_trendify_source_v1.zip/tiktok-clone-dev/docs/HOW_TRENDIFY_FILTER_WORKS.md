# How the Trendify AI Style Transfer Filter Works

## Overview

Trendify's signature feature is the **Trend Filter** — an AI-powered style transfer system that transforms video frames in real-time into artistic styles (Anime, Sketch, Oil Painting, Watercolor, Pop Art). Videos created with a Trend Filter earn a **🔥 Trend badge** in the feed to encourage virality.

## Architecture

```
┌─────────────────────────────────────────────────────────┐
│  Flutter App (On-Device)                                │
│                                                         │
│  ┌──────────┐    ┌───────────────────┐    ┌──────────┐ │
│  │  Camera   │───▶│ StyleTransferEngine│───▶│ Preview  │ │
│  │  Stream   │    │  (TFLite model)   │    │ Display  │ │
│  └──────────┘    └───────────────────┘    └──────────┘ │
│       │                   │                      │      │
│       │          ┌────────┴────────┐             │      │
│       │          │ StyleFilterProvider │          │      │
│       │          │ (manages state)    │          │      │
│       │          └────────┬────────┘             │      │
│       │                   │                      │      │
│       ▼                   ▼                      ▼      │
│  ┌─────────────────────────────────────────────────┐   │
│  │            StyleToggleCarousel (UI)              │   │
│  │  [None] [Anime] [Sketch] [Oil] [Water] [Pop]   │   │
│  └─────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────┘
                          │
                    Upload with metadata
                          │
                          ▼
┌─────────────────────────────────────────────────────────┐
│  Node.js Backend                                        │
│                                                         │
│  POST /api/upload                                       │
│  ├── Video file saved to disk                           │
│  ├── styleTransferService.applyStyle(path, styleName)   │
│  │   └── (Optional server-side re-processing)           │
│  ├── Video record created with styleFilter metadata     │
│  │   └── { applied: true, styleName: "anime", ... }     │
│  └── isTrending: true (auto-set for styled videos)      │
│                                                         │
│  GET /api/feed                                          │
│  └── Each video includes hasTrendBadge: true/false      │
│                                                         │
│  GET /api/styles                                        │
│  └── Returns available styles + model info              │
└─────────────────────────────────────────────────────────┘
```

## Processing Pipeline (Per Frame)

### Step 1: Frame Capture
```dart
// CameraController streams frames at ~30fps
controller.startImageStream((CameraImage image) {
  final rgbaBytes = _convertYUV420toRGBA(image);
  // rgbaBytes is Uint8List of width × height × 4 bytes
});
```

### Step 2: Preprocessing
```dart
// Resize to model input size (typically 256×256)
// Normalize pixel values from [0, 255] to [0.0, 1.0]
Float32List _preprocess(Uint8List rgba, int w, int h) {
  final input = Float32List(1 * h * w * 3);  // [batch, h, w, channels]
  for (int i = 0; i < w * h; i++) {
    input[i * 3 + 0] = rgba[i * 4 + 0] / 255.0; // R
    input[i * 3 + 1] = rgba[i * 4 + 1] / 255.0; // G
    input[i * 3 + 2] = rgba[i * 4 + 2] / 255.0; // B
  }
  return input;
}
```

### Step 3: TFLite Inference
```dart
// Load model once when user selects a style
final interpreter = await Interpreter.fromAsset(
  'models/anime_style_v1.tflite',
  options: InterpreterOptions()
    ..threads = 4
    ..addDelegate(GpuDelegateV2()),  // GPU acceleration
);

// Run on each frame
final output = Float32List(1 * 256 * 256 * 3);
interpreter.run(preprocessed, output);
```

### Step 4: Postprocessing
```dart
// Convert float [0.0, 1.0] back to RGBA [0, 255]
Uint8List _postprocess(Float32List output, int w, int h) {
  final rgba = Uint8List(w * h * 4);
  for (int i = 0; i < w * h; i++) {
    rgba[i * 4 + 0] = (output[i * 3 + 0] * 255).clamp(0, 255).toInt(); // R
    rgba[i * 4 + 1] = (output[i * 3 + 1] * 255).clamp(0, 255).toInt(); // G
    rgba[i * 4 + 2] = (output[i * 3 + 2] * 255).clamp(0, 255).toInt(); // B
    rgba[i * 4 + 3] = 255;  // A (fully opaque)
  }
  return rgba;
}
```

### Step 5: Display
The styled frame replaces the camera preview via a `RawImage` widget or `CustomPainter`.

## Style Toggle Flow

```
User taps "Sketch" in StyleToggleCarousel
    │
    ▼
StyleFilterProvider.selectStyle(sketchModel)
    │
    ├── Sets isProcessing = true (shows loading spinner)
    ├── Disposes previous TFLite interpreter
    ├── Loads sketch_style_v1.tflite
    ├── Sets _selectedStyle = sketchModel
    └── Sets isProcessing = false
    │
    ▼
Camera preview now shows each frame processed through sketch model
    │
    ▼
User taps Record → frames written with style applied
    │
    ▼
Upload screen → styleName: "sketch" sent with video file
    │
    ▼
Backend creates Video record with styleFilter.applied = true
    │
    ▼
Feed displays 🔥 Trend · Sketch badge on this video
```

## Adding a Custom Filter

### TFLite Model (AI Style)
1. Train a style transfer model using TensorFlow (Arbitrary Image Stylization or CycleGAN)
2. Convert: `tf.lite.TFLiteConverter.from_saved_model(path)` → `.tflite`
3. Place in `flutter_app/assets/models/<name>_style_v1.tflite`
4. Add to `StyleFilterModel.defaults` in `style_filter_model.dart`
5. Add to backend's `config.styleTransfer.availableStyles` array
6. The `StyleTransferEngine.loadModel()` picks it up automatically

### GLSL Shader (Color Grading / GPU Effects)
1. Write a fragment shader in `assets/shaders/<name>.frag`
2. Register in `pubspec.yaml` under `flutter.shaders`
3. Load via `ShaderFilterEngine.loadShader()`
4. Applied via `CustomPainter` composited over camera preview

### AR Filter (Face/Body Tracking)
1. Integrate Google ML Kit Face Mesh (468 3D landmarks)
2. Map textures onto face mesh vertices
3. Render via `CustomPainter` on top of camera preview
4. For 3D objects: use a scene renderer anchored to landmarks

## Trend Badge Logic

A video gets `hasTrendBadge: true` when:
```javascript
// Backend (Video model virtual)
hasTrendBadge = styleFilter.applied === true
             && styleFilter.styleName !== 'none'
```

The `TrendBadge` widget renders a gradient pill with the style name:
```
🔥 Trend · Anime
```

This appears:
- **Feed**: Top-right corner of each video card
- **Profile grid**: Small 🔥 overlay on thumbnails
- **Upload screen**: Confirmation that trend filter is applied
