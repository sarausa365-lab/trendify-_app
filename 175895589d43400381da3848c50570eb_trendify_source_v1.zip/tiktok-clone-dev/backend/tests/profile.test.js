const request = require('supertest');

jest.mock('mongoose', () => {
  const actualMongoose = jest.requireActual('mongoose');
  return {
    ...actualMongoose,
    connect: jest.fn().mockResolvedValue(true),
    model: jest.fn(),
    Schema: actualMongoose.Schema,
  };
});

const users = [];
const videos = [];

jest.mock('../src/models/User', () => {
  function MockUser(data) {
    this._id = data._id || `user_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    this.username = data.username;
    this.email = data.email;
    this.passwordHash = data.passwordHash;
    this.displayName = data.displayName || data.username;
    this.avatarUrl = data.avatarUrl || '';
    this.bio = data.bio || '';
    this.followers = 0;
    this.following = 0;
    this.createdAt = new Date();
  }

  MockUser.prototype.save = async function () {
    const dup = users.find((u) => u.email === this.email || u.username === this.username);
    if (dup) { const err = new Error('Duplicate key'); err.code = 11000; throw err; }
    users.push(this);
    return this;
  };

  MockUser.prototype.toObject = function () { return { ...this }; };

  MockUser.findOne = async function (query) {
    if (query.$or) {
      return users.find((u) => u.email === query.$or[0].email || u.username === query.$or[1].username) || null;
    }
    if (query.email) return users.find((u) => u.email === query.email) || null;
    return null;
  };

  MockUser.findById = function (id) {
    const user = users.find((u) => u._id === id);
    return { lean: () => Promise.resolve(user ? { ...user } : null) };
  };

  MockUser.findByIdAndUpdate = function (id, updates, opts) {
    const idx = users.findIndex((u) => u._id === id);
    if (idx === -1) return { lean: () => Promise.resolve(null) };
    Object.assign(users[idx], updates);
    return { lean: () => Promise.resolve({ ...users[idx] }) };
  };

  return MockUser;
});

jest.mock('../src/models/Video', () => {
  function MockVideo(data) {
    Object.assign(this, data);
    this._id = `vid_${Date.now()}`;
  }

  MockVideo.countDocuments = async function (query) {
    return videos.filter((v) => {
      if (query.userId && v.userId !== query.userId) return false;
      if (query['styleFilter.applied'] !== undefined && v.styleFilter?.applied !== query['styleFilter.applied']) return false;
      if (query['styleFilter.styleName']?.$ne && v.styleFilter?.styleName === query['styleFilter.styleName'].$ne) return false;
      return true;
    }).length;
  };

  MockVideo.aggregate = async function (pipeline) {
    const match = pipeline[0]?.$match || {};
    const matched = videos.filter((v) => {
      if (match.userId && v.userId !== match.userId) return false;
      return true;
    });
    const total = matched.reduce((sum, v) => sum + (v.stats?.likes || 0), 0);
    return total > 0 ? [{ _id: null, total }] : [];
  };

  MockVideo.find = function (query) {
    let result = [...videos];
    if (query?.userId) result = result.filter((v) => v.userId === query.userId);
    if (query?.['styleFilter.applied']) {
      result = result.filter((v) => v.styleFilter?.applied === true);
    }
    if (query?.['styleFilter.styleName']?.$ne) {
      result = result.filter((v) => v.styleFilter?.styleName !== query['styleFilter.styleName'].$ne);
    }
    return {
      sort: function () { return this; },
      skip: function () { return this; },
      limit: function () { return this; },
      lean: () => Promise.resolve(result),
    };
  };

  return MockVideo;
});

const app = require('../src/app');

let testToken;
let testUserId;

beforeEach(async () => {
  users.length = 0;
  videos.length = 0;

  const res = await request(app)
    .post('/api/auth/signup')
    .send({ username: 'profileuser', email: 'profile@trendify.com', password: 'pass123456', displayName: 'Profile Tester' });

  testToken = res.body.data.token;
  testUserId = res.body.data.user._id;

  // Add some mock videos
  videos.push(
    { userId: testUserId, caption: 'Trend vid', styleFilter: { applied: true, styleName: 'anime' }, stats: { likes: 100 } },
    { userId: testUserId, caption: 'Normal vid', styleFilter: { applied: false, styleName: 'none' }, stats: { likes: 50 } },
    { userId: testUserId, caption: 'Sketch vid', styleFilter: { applied: true, styleName: 'sketch' }, stats: { likes: 200 } },
    { userId: 'other_user', caption: 'Other vid', styleFilter: { applied: false, styleName: 'none' }, stats: { likes: 10 } },
  );
});

describe('GET /api/profile/me', () => {
  it('should return authenticated user profile with stats', async () => {
    const res = await request(app)
      .get('/api/profile/me')
      .set('Authorization', `Bearer ${testToken}`);

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.user.username).toBe('profileuser');
    expect(res.body.data.user.displayName).toBe('Profile Tester');
    expect(res.body.data.user.passwordHash).toBeUndefined();
    expect(res.body.data.stats.totalVideos).toBe(3);
    expect(res.body.data.stats.trendVideos).toBe(2);
    expect(res.body.data.stats.totalLikes).toBe(350);
  });

  it('should reject without auth', async () => {
    const res = await request(app).get('/api/profile/me');
    expect(res.status).toBe(401);
  });
});

describe('GET /api/profile/me/videos', () => {
  it('should return all user videos', async () => {
    const res = await request(app)
      .get('/api/profile/me/videos')
      .set('Authorization', `Bearer ${testToken}`);

    expect(res.status).toBe(200);
    expect(res.body.data.length).toBe(3);
  });

  it('should filter for trend videos only', async () => {
    const res = await request(app)
      .get('/api/profile/me/videos?trend=true')
      .set('Authorization', `Bearer ${testToken}`);

    expect(res.status).toBe(200);
    expect(res.body.data.length).toBe(2);
    res.body.data.forEach((v) => {
      expect(v.hasTrendBadge).toBe(true);
    });
  });
});

describe('PUT /api/profile/me', () => {
  it('should update displayName and bio', async () => {
    const res = await request(app)
      .put('/api/profile/me')
      .set('Authorization', `Bearer ${testToken}`)
      .send({ displayName: 'Updated Name', bio: 'Trendify creator 🔥' });

    expect(res.status).toBe(200);
    expect(res.body.data.displayName).toBe('Updated Name');
    expect(res.body.data.bio).toBe('Trendify creator 🔥');
  });

  it('should reject with no valid fields', async () => {
    const res = await request(app)
      .put('/api/profile/me')
      .set('Authorization', `Bearer ${testToken}`)
      .send({ hackerField: 'malicious' });

    expect(res.status).toBe(400);
  });
});

describe('GET /api/profile/:userId', () => {
  it('should return public profile by userId', async () => {
    const res = await request(app).get(`/api/profile/${testUserId}`);

    expect(res.status).toBe(200);
    expect(res.body.data.user.username).toBe('profileuser');
  });

  it('should 404 for non-existent user', async () => {
    const res = await request(app).get('/api/profile/nonexistent_id');
    expect(res.status).toBe(404);
  });
});
