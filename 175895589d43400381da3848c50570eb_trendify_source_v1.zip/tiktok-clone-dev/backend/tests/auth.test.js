const request = require('supertest');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

// Mock mongoose before requiring app
jest.mock('mongoose', () => {
  const actualMongoose = jest.requireActual('mongoose');
  return {
    ...actualMongoose,
    connect: jest.fn().mockResolvedValue(true),
    model: jest.fn(),
    Schema: actualMongoose.Schema,
  };
});

// In-memory user store for testing
const users = [];

jest.mock('../src/models/User', () => {
  const bcrypt = require('bcryptjs');

  function MockUser(data) {
    this._id = data._id || `user_${Date.now()}_${Math.random().toString(36).slice(2)}`;
    this.username = data.username;
    this.email = data.email;
    this.passwordHash = data.passwordHash;
    this.displayName = data.displayName || data.username;
    this.avatarUrl = data.avatarUrl || '';
    this.bio = data.bio || '';
    this.followers = 0;
    this.following = 0;
    this.createdAt = new Date();
  }

  MockUser.prototype.save = async function () {
    // Check unique constraints
    const dup = users.find(
      (u) => u.email === this.email || u.username === this.username
    );
    if (dup) {
      const err = new Error('Duplicate key');
      err.code = 11000;
      throw err;
    }
    users.push(this);
    return this;
  };

  MockUser.prototype.toObject = function () {
    return { ...this };
  };

  MockUser.findOne = async function (query) {
    if (query.$or) {
      return users.find(
        (u) =>
          u.email === query.$or[0].email ||
          u.username === query.$or[1].username
      ) || null;
    }
    if (query.email) {
      return users.find((u) => u.email === query.email) || null;
    }
    return null;
  };

  MockUser.findById = function (id) {
    const user = users.find((u) => u._id === id);
    return {
      lean: () => Promise.resolve(user ? { ...user } : null),
    };
  };

  return MockUser;
});

const app = require('../src/app');
const config = require('../src/config');

beforeEach(() => {
  users.length = 0;
});

describe('POST /api/auth/signup', () => {
  it('should create a new user and return token', async () => {
    const res = await request(app)
      .post('/api/auth/signup')
      .send({
        username: 'trenduser',
        email: 'trend@trendify.com',
        password: 'securepass123',
        displayName: 'Trend User',
      });

    expect(res.status).toBe(201);
    expect(res.body.success).toBe(true);
    expect(res.body.data.token).toBeDefined();
    expect(res.body.data.user.username).toBe('trenduser');
    expect(res.body.data.user.displayName).toBe('Trend User');
    expect(res.body.data.user.passwordHash).toBeUndefined();

    // Verify token is valid
    const decoded = jwt.verify(res.body.data.token, config.jwtSecret);
    expect(decoded.userId).toBeDefined();
  });

  it('should reject missing fields', async () => {
    const res = await request(app)
      .post('/api/auth/signup')
      .send({ username: 'test' });

    expect(res.status).toBe(400);
    expect(res.body.success).toBe(false);
    expect(res.body.error).toContain('required');
  });

  it('should reject short username', async () => {
    const res = await request(app)
      .post('/api/auth/signup')
      .send({ username: 'ab', email: 'ab@test.com', password: 'pass123' });

    expect(res.status).toBe(400);
    expect(res.body.error).toContain('3-30');
  });

  it('should reject invalid email', async () => {
    const res = await request(app)
      .post('/api/auth/signup')
      .send({ username: 'testuser', email: 'notanemail', password: 'pass123' });

    expect(res.status).toBe(400);
    expect(res.body.error).toContain('email');
  });

  it('should reject short password', async () => {
    const res = await request(app)
      .post('/api/auth/signup')
      .send({ username: 'testuser', email: 'test@t.com', password: '12345' });

    expect(res.status).toBe(400);
    expect(res.body.error).toContain('6 characters');
  });

  it('should reject duplicate email', async () => {
    await request(app)
      .post('/api/auth/signup')
      .send({ username: 'user1', email: 'dup@test.com', password: 'pass123' });

    const res = await request(app)
      .post('/api/auth/signup')
      .send({ username: 'user2', email: 'dup@test.com', password: 'pass123' });

    expect(res.status).toBe(409);
    expect(res.body.error).toContain('already exists');
  });
});

describe('POST /api/auth/login', () => {
  beforeEach(async () => {
    await request(app)
      .post('/api/auth/signup')
      .send({ username: 'logintest', email: 'login@trendify.com', password: 'pass123456' });
  });

  it('should login with valid credentials and return token', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: 'login@trendify.com', password: 'pass123456' });

    expect(res.status).toBe(200);
    expect(res.body.success).toBe(true);
    expect(res.body.data.token).toBeDefined();
    expect(res.body.data.user.username).toBe('logintest');
    expect(res.body.data.user.passwordHash).toBeUndefined();
  });

  it('should reject wrong password', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: 'login@trendify.com', password: 'wrongpass' });

    expect(res.status).toBe(401);
    expect(res.body.error).toContain('Invalid');
  });

  it('should reject non-existent email', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: 'noone@nowhere.com', password: 'pass123' });

    expect(res.status).toBe(401);
  });

  it('should reject missing fields', async () => {
    const res = await request(app)
      .post('/api/auth/login')
      .send({ email: 'login@trendify.com' });

    expect(res.status).toBe(400);
    expect(res.body.error).toContain('required');
  });
});

describe('GET /api/auth/me', () => {
  it('should return current user with valid token', async () => {
    const signupRes = await request(app)
      .post('/api/auth/signup')
      .send({ username: 'metest', email: 'me@trendify.com', password: 'pass123456' });

    const token = signupRes.body.data.token;

    const res = await request(app)
      .get('/api/auth/me')
      .set('Authorization', `Bearer ${token}`);

    expect(res.status).toBe(200);
    expect(res.body.data.username).toBe('metest');
    expect(res.body.data.passwordHash).toBeUndefined();
  });

  it('should reject request without token', async () => {
    const res = await request(app).get('/api/auth/me');
    expect(res.status).toBe(401);
  });

  it('should reject invalid token', async () => {
    const res = await request(app)
      .get('/api/auth/me')
      .set('Authorization', 'Bearer invalid.token.here');

    expect(res.status).toBe(401);
  });
});

describe('GET /api/health', () => {
  it('should return Trendify health status', async () => {
    const res = await request(app).get('/api/health');
    expect(res.status).toBe(200);
    expect(res.body.status).toBe('ok');
    expect(res.body.app).toBe('Trendify API');
  });
});
