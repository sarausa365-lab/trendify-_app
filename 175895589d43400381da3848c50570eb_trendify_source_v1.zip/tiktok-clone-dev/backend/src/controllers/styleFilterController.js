const StyleFilter = require('../models/StyleFilter');
const styleTransferService = require('../services/styleTransferService');

exports.getAvailableStyles = async (req, res) => {
  try {
    // Return from DB if populated, otherwise fall back to service config
    let filters = await StyleFilter.find({ isActive: true }).lean();

    if (filters.length === 0) {
      filters = styleTransferService.getAvailableStyles();
    }

    res.json({ success: true, data: filters });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

exports.getStyleById = async (req, res) => {
  try {
    const filter = await StyleFilter.findById(req.params.id).lean();
    if (!filter) {
      return res.status(404).json({ success: false, error: 'Style filter not found' });
    }
    res.json({ success: true, data: filter });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

exports.getStyleByName = async (req, res) => {
  try {
    const { name } = req.params;
    if (!styleTransferService.isValidStyle(name)) {
      return res.status(400).json({ success: false, error: `Unknown style: ${name}` });
    }

    const filter = await StyleFilter.findOne({ name }).lean();
    if (!filter) {
      // Return config-based info
      const styles = styleTransferService.getAvailableStyles();
      const match = styles.find((s) => s.name === name);
      return res.json({ success: true, data: match });
    }

    res.json({ success: true, data: filter });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
