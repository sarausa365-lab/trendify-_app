const User = require('../models/User');
const Video = require('../models/Video');

exports.getProfile = async (req, res) => {
  try {
    const userId = req.params.userId || req.userId;

    const user = await User.findById(userId).lean();
    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }
    delete user.passwordHash;
    delete user.__v;

    const totalVideos = await Video.countDocuments({ userId });
    const trendVideos = await Video.countDocuments({
      userId,
      'styleFilter.applied': true,
      'styleFilter.styleName': { $ne: 'none' },
    });

    const totalLikes = await Video.aggregate([
      { $match: { userId: user._id } },
      { $group: { _id: null, total: { $sum: '$stats.likes' } } },
    ]);

    res.json({
      success: true,
      data: {
        user,
        stats: {
          totalVideos,
          trendVideos,
          totalLikes: totalLikes.length > 0 ? totalLikes[0].total : 0,
        },
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

exports.getUserVideos = async (req, res) => {
  try {
    const userId = req.params.userId || req.userId;
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit) || 20));
    const skip = (page - 1) * limit;
    const filterTrend = req.query.trend === 'true';

    const query = { userId };
    if (filterTrend) {
      query['styleFilter.applied'] = true;
      query['styleFilter.styleName'] = { $ne: 'none' };
    }

    const videos = await Video.find(query)
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .lean();

    const enriched = videos.map((v) => ({
      ...v,
      hasTrendBadge: v.styleFilter?.applied && v.styleFilter?.styleName !== 'none',
    }));

    res.json({ success: true, page, limit, data: enriched });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

exports.updateProfile = async (req, res) => {
  try {
    const allowedFields = ['displayName', 'bio', 'avatarUrl'];
    const updates = {};
    for (const field of allowedFields) {
      if (req.body[field] !== undefined) {
        updates[field] = req.body[field];
      }
    }

    if (Object.keys(updates).length === 0) {
      return res.status(400).json({ success: false, error: 'No valid fields to update' });
    }

    const user = await User.findByIdAndUpdate(req.userId, updates, { new: true }).lean();
    if (!user) {
      return res.status(404).json({ success: false, error: 'User not found' });
    }
    delete user.passwordHash;
    delete user.__v;

    res.json({ success: true, data: user });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
