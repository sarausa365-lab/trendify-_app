const Video = require('../models/Video');

exports.getFeed = async (req, res) => {
  try {
    const page = Math.max(1, parseInt(req.query.page) || 1);
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit) || 20));
    const skip = (page - 1) * limit;

    const videos = await Video.find()
      .sort({ createdAt: -1 })
      .skip(skip)
      .limit(limit)
      .populate('userId', 'username displayName avatarUrl')
      .lean();

    // Attach hasTrendBadge for each video
    const enriched = videos.map((v) => ({
      ...v,
      hasTrendBadge: v.styleFilter?.applied && v.styleFilter?.styleName !== 'none',
    }));

    res.json({ success: true, page, limit, data: enriched });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

exports.getTrending = async (req, res) => {
  try {
    const limit = Math.min(50, Math.max(1, parseInt(req.query.limit) || 20));

    const videos = await Video.find({
      'styleFilter.applied': true,
      isTrending: true,
    })
      .sort({ 'stats.views': -1, createdAt: -1 })
      .limit(limit)
      .populate('userId', 'username displayName avatarUrl')
      .lean();

    const enriched = videos.map((v) => ({
      ...v,
      hasTrendBadge: true,
    }));

    res.json({ success: true, data: enriched });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};

exports.getVideoById = async (req, res) => {
  try {
    const video = await Video.findById(req.params.id)
      .populate('userId', 'username displayName avatarUrl')
      .lean();

    if (!video) {
      return res.status(404).json({ success: false, error: 'Video not found' });
    }

    video.hasTrendBadge = video.styleFilter?.applied && video.styleFilter?.styleName !== 'none';

    res.json({ success: true, data: video });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
