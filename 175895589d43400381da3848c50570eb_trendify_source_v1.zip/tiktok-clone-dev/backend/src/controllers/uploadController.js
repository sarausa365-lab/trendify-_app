const Video = require('../models/Video');
const StyleFilter = require('../models/StyleFilter');
const styleTransferService = require('../services/styleTransferService');
const videoService = require('../services/videoService');

exports.uploadVideo = async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ success: false, error: 'No video file provided' });
    }

    if (!videoService.isAllowedFormat(req.file.originalname)) {
      return res.status(400).json({ success: false, error: 'Unsupported video format' });
    }

    const { caption, tags, styleName } = req.body;
    const userId = req.userId; // set by auth middleware

    let styleResult = null;
    if (styleName && styleName !== 'none') {
      styleResult = await styleTransferService.applyStyle(req.file.path, styleName);

      // Increment usage count for the filter
      await StyleFilter.findOneAndUpdate(
        { name: styleName },
        { $inc: { usageCount: 1 } }
      );
    }

    const videoRecord = videoService.buildVideoRecord({
      userId,
      filePath: req.file.path,
      caption,
      tags: tags ? tags.split(',').map((t) => t.trim()) : [],
      styleResult,
    });

    const video = new Video(videoRecord);
    await video.save();

    res.status(201).json({
      success: true,
      data: {
        id: video._id,
        videoUrl: video.videoUrl,
        hasTrendBadge: video.hasTrendBadge,
        styleFilter: video.styleFilter,
      },
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
};
