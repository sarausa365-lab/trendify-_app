const { v4: uuidv4 } = require('uuid');
const path = require('path');
const config = require('../config');

class VideoService {
  buildVideoRecord({ userId, filePath, caption, tags, styleResult }) {
    const videoRecord = {
      userId,
      videoUrl: `/videos/${path.basename(filePath)}`,
      caption: caption || '',
      tags: tags || [],
      styleFilter: {
        applied: !!styleResult,
        styleName: styleResult ? styleResult.styleName : 'none',
        modelVersion: styleResult ? styleResult.modelVersion : '',
        processingTime: styleResult ? styleResult.processingTime : 0,
      },
      isTrending: !!styleResult,
      stats: { views: 0, likes: 0, shares: 0, comments: 0 },
      duration: 0,
      width: 0,
      height: 0,
    };
    return videoRecord;
  }

  generateFilename(originalName) {
    const ext = path.extname(originalName);
    return `${uuidv4()}${ext}`;
  }

  isAllowedFormat(filename) {
    const ext = path.extname(filename).replace('.', '').toLowerCase();
    return config.allowedVideoFormats.includes(ext);
  }
}

module.exports = new VideoService();
