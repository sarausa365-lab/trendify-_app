const config = require('../config');

class StyleTransferService {
  constructor() {
    this.availableStyles = config.styleTransfer.availableStyles;
    this.modelBasePath = config.styleTransfer.modelBasePath;
  }

  getAvailableStyles() {
    return this.availableStyles.map((style) => ({
      name: style,
      displayName: this.formatDisplayName(style),
      modelFile: `${style}_style_v1.tflite`,
    }));
  }

  isValidStyle(styleName) {
    return this.availableStyles.includes(styleName);
  }

  formatDisplayName(styleName) {
    return styleName
      .split('_')
      .map((w) => w.charAt(0).toUpperCase() + w.slice(1))
      .join(' ');
  }

  /**
   * Server-side style transfer processing.
   * In production this would invoke a TFLite/ONNX model or
   * dispatch to a GPU worker queue. For this scaffold it returns
   * metadata about what *would* happen.
   */
  async applyStyle(videoPath, styleName) {
    if (!this.isValidStyle(styleName)) {
      throw new Error(`Invalid style: ${styleName}. Available: ${this.availableStyles.join(', ')}`);
    }

    const startTime = Date.now();

    // Placeholder: real implementation loads the TFLite model,
    // decodes each frame, runs inference, re-encodes the video.
    const result = {
      success: true,
      styleName,
      modelFile: `${styleName}_style_v1.tflite`,
      modelVersion: '1.0',
      processingTime: Date.now() - startTime,
      outputPath: videoPath.replace(/(\.\w+)$/, `_${styleName}$1`),
    };

    return result;
  }
}

module.exports = new StyleTransferService();
