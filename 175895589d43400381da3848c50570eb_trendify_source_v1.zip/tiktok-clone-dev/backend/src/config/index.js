require('dotenv').config();

module.exports = {
  port: process.env.PORT || 3000,
  mongodbUri: process.env.MONGODB_URI || 'mongodb://localhost:27017/tiktok_clone',
  jwtSecret: process.env.JWT_SECRET || 'dev-secret-change-in-production',
  jwtExpiresIn: process.env.JWT_EXPIRES_IN || '7d',
  uploadDir: process.env.UPLOAD_DIR || './uploads',
  maxVideoSizeMB: parseInt(process.env.MAX_VIDEO_SIZE_MB || '100', 10),
  allowedVideoFormats: (process.env.ALLOWED_VIDEO_FORMATS || 'mp4,mov,avi').split(','),
  ffmpegPath: process.env.FFMPEG_PATH || '/usr/bin/ffmpeg',
  bcryptRounds: parseInt(process.env.BCRYPT_ROUNDS || '10', 10),
  styleTransfer: {
    enabled: true,
    availableStyles: ['anime', 'sketch', 'oil_painting', 'watercolor', 'pop_art'],
    defaultStyle: 'anime',
    modelBasePath: process.env.STYLE_MODEL_PATH || './models/style_transfer',
  },
};
