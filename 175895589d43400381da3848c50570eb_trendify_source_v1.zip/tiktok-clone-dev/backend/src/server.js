const mongoose = require('mongoose');
const app = require('./app');
const config = require('./config');

async function start() {
  try {
    await mongoose.connect(config.mongodbUri);
    console.log('Connected to MongoDB');
  } catch (err) {
    console.warn('MongoDB connection failed, running without DB:', err.message);
  }

  app.listen(config.port, () => {
    console.log(`TikTok Clone API running on port ${config.port}`);
  });
}

start();
