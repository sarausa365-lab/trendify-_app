const express = require('express');
const router = express.Router();
const uploadMiddleware = require('../middleware/upload');
const authMiddleware = require('../middleware/auth');
const uploadController = require('../controllers/uploadController');

router.post(
  '/',
  authMiddleware,
  uploadMiddleware.single('video'),
  uploadController.uploadVideo
);

module.exports = router;
