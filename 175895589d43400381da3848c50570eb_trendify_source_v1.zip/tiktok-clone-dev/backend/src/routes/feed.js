const express = require('express');
const router = express.Router();
const feedController = require('../controllers/feedController');

router.get('/', feedController.getFeed);
router.get('/trending', feedController.getTrending);
router.get('/:id', feedController.getVideoById);

module.exports = router;
