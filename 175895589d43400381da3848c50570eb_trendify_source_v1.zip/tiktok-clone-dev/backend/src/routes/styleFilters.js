const express = require('express');
const router = express.Router();
const styleFilterController = require('../controllers/styleFilterController');

router.get('/', styleFilterController.getAvailableStyles);
router.get('/name/:name', styleFilterController.getStyleByName);
router.get('/:id', styleFilterController.getStyleById);

module.exports = router;
