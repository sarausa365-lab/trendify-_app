const express = require('express');
const router = express.Router();
const profileController = require('../controllers/profileController');
const authMiddleware = require('../middleware/auth');

router.get('/me', authMiddleware, profileController.getProfile);
router.get('/me/videos', authMiddleware, profileController.getUserVideos);
router.put('/me', authMiddleware, profileController.updateProfile);
router.get('/:userId', profileController.getProfile);
router.get('/:userId/videos', profileController.getUserVideos);

module.exports = router;
