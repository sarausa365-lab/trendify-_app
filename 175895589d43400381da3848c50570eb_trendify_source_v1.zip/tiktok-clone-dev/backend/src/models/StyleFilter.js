const mongoose = require('mongoose');

const styleFilterSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    unique: true,
    enum: ['anime', 'sketch', 'oil_painting', 'watercolor', 'pop_art'],
  },
  displayName: { type: String, required: true },
  description: { type: String, default: '' },
  thumbnailUrl: { type: String, default: '' },
  modelFileName: { type: String, required: true }, // e.g. "anime_style_v2.tflite"
  modelVersion: { type: String, default: '1.0' },
  inputSize: { width: { type: Number, default: 256 }, height: { type: Number, default: 256 } },
  isActive: { type: Boolean, default: true },
  usageCount: { type: Number, default: 0 },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.model('StyleFilter', styleFilterSchema);
