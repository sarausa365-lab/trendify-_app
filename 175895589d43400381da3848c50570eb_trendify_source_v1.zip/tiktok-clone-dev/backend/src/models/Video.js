const mongoose = require('mongoose');

const videoSchema = new mongoose.Schema({
  userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  videoUrl: { type: String, required: true },
  thumbnailUrl: { type: String, default: '' },
  caption: { type: String, default: '', maxlength: 500 },
  tags: [{ type: String }],

  // AI Style Transfer / Trend Filter metadata
  styleFilter: {
    applied: { type: Boolean, default: false },
    styleName: {
      type: String,
      enum: ['none', 'anime', 'sketch', 'oil_painting', 'watercolor', 'pop_art'],
      default: 'none',
    },
    modelVersion: { type: String, default: '' },
    processingTime: { type: Number, default: 0 }, // ms
  },
  isTrending: { type: Boolean, default: false },

  stats: {
    views: { type: Number, default: 0 },
    likes: { type: Number, default: 0 },
    shares: { type: Number, default: 0 },
    comments: { type: Number, default: 0 },
  },

  duration: { type: Number, default: 0 }, // seconds
  width: { type: Number, default: 0 },
  height: { type: Number, default: 0 },

  createdAt: { type: Date, default: Date.now },
  updatedAt: { type: Date, default: Date.now },
});

videoSchema.index({ createdAt: -1 });
videoSchema.index({ 'styleFilter.applied': 1, isTrending: 1 });
videoSchema.index({ 'stats.views': -1 });

videoSchema.virtual('hasTrendBadge').get(function () {
  return this.styleFilter.applied && this.styleFilter.styleName !== 'none';
});

videoSchema.set('toJSON', { virtuals: true });
videoSchema.set('toObject', { virtuals: true });

module.exports = mongoose.model('Video', videoSchema);
