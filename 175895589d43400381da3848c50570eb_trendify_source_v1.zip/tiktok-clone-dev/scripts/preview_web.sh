#!/usr/bin/env bash
# ============================================================
#  Trendify Beta – Web Preview Script
# ============================================================
#  Starts the Node.js backend in dev mode and, if Flutter is
#  installed, launches the Flutter web build. Otherwise serves
#  a static HTML preview showing the app structure.
#
#  Usage:  bash scripts/preview_web.sh
# ============================================================

set -e
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
ROOT_DIR="$(cd "$SCRIPT_DIR/.." && pwd)"

GREEN='\033[0;32m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}╔══════════════════════════════════════╗${NC}"
echo -e "${CYAN}║    🔥  Trendify Beta Preview  🔥    ║${NC}"
echo -e "${CYAN}╚══════════════════════════════════════╝${NC}"

# ── 1. Start backend ─────────────────────────────────────
echo -e "\n${GREEN}[1/3] Starting Trendify Backend...${NC}"
cd "$ROOT_DIR/backend"
if [ ! -d "node_modules" ]; then
  echo "  Installing dependencies..."
  npm install --silent
fi
mkdir -p uploads

# Start in background; kill on exit
node src/server.js &
BACKEND_PID=$!
echo "  Backend PID: $BACKEND_PID (port 3000)"

sleep 2

# Healthcheck
if curl -s http://localhost:3000/api/health | grep -q '"ok"'; then
  echo -e "  ${GREEN}✓ Backend healthy${NC}"
else
  echo "  ⚠ Backend may not be fully ready (MongoDB not connected is OK for demo)"
fi

# ── 2. Try Flutter web, fall back to static HTML ─────────
echo -e "\n${GREEN}[2/3] Setting up Web Preview...${NC}"

if command -v flutter &>/dev/null; then
  echo "  Flutter detected — building web..."
  cd "$ROOT_DIR/flutter_app"
  flutter build web --release 2>/dev/null || true
  if [ -d "build/web" ]; then
    echo "  Serving Flutter web on port 8080"
    cd build/web && python3 -m http.server 8080 &
    WEB_PID=$!
  fi
else
  echo "  Flutter not installed — serving static HTML preview..."
  cd "$ROOT_DIR"
  python3 -m http.server 8080 --directory "$ROOT_DIR/docs" &
  WEB_PID=$!
fi

# ── 3. Summary ───────────────────────────────────────────
echo -e "\n${GREEN}[3/3] Trendify Beta Preview Ready!${NC}"
echo "  ─────────────────────────────────────"
echo "  Backend API:   http://localhost:3000/api/health"
echo "  Web Preview:   http://localhost:8080"
echo "  ─────────────────────────────────────"
echo ""
echo "  Press Ctrl+C to stop."

# Cleanup on exit
cleanup() {
  echo -e "\n${CYAN}Stopping Trendify services...${NC}"
  kill $BACKEND_PID 2>/dev/null || true
  kill $WEB_PID 2>/dev/null || true
  echo "Done."
}
trap cleanup EXIT INT TERM

wait
