import 'package:flutter/material.dart';
import '../models/style_filter_model.dart';

/// Horizontal scrollable toggle for switching between AI styles.
/// Shows "None" + all available styles. The active style is highlighted.
class StyleToggleCarousel extends StatelessWidget {
  final List<StyleFilterModel> styles;
  final String? activeStyleName;
  final bool isLoading;
  final ValueChanged<StyleFilterModel?> onStyleSelected;

  const StyleToggleCarousel({
    super.key,
    required this.styles,
    required this.activeStyleName,
    required this.onStyleSelected,
    this.isLoading = false,
  });

  static const _icons = <String, IconData>{
    'anime': Icons.animation,
    'sketch': Icons.edit,
    'oil_painting': Icons.brush,
    'watercolor': Icons.water_drop,
    'pop_art': Icons.color_lens,
  };

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 90,
      child: ListView(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        children: [
          _buildChip(
            context,
            label: 'None',
            icon: Icons.block,
            isActive: activeStyleName == null,
            onTap: () => onStyleSelected(null),
          ),
          ...styles.map((style) => _buildChip(
                context,
                label: style.displayName,
                icon: _icons[style.name] ?? Icons.auto_awesome,
                isActive: activeStyleName == style.name,
                onTap: () => onStyleSelected(style),
              )),
        ],
      ),
    );
  }

  Widget _buildChip(
    BuildContext context, {
    required String label,
    required IconData icon,
    required bool isActive,
    required VoidCallback onTap,
  }) {
    return GestureDetector(
      onTap: isLoading ? null : onTap,
      child: Container(
        width: 70,
        margin: const EdgeInsets.symmetric(horizontal: 6),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isActive
                    ? const Color(0xFFFF2D55)
                    : Colors.white.withOpacity(0.15),
                border: Border.all(
                  color: isActive ? Colors.white : Colors.white38,
                  width: isActive ? 2.5 : 1,
                ),
              ),
              child: isLoading && isActive
                  ? const Padding(
                      padding: EdgeInsets.all(14),
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        color: Colors.white,
                      ),
                    )
                  : Icon(icon, color: Colors.white, size: 24),
            ),
            const SizedBox(height: 6),
            Text(
              label,
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(
                color: isActive ? Colors.white : Colors.white70,
                fontSize: 11,
                fontWeight: isActive ? FontWeight.w700 : FontWeight.w400,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
