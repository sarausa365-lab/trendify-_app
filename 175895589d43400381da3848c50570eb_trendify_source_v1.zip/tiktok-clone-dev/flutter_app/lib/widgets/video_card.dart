import 'package:flutter/material.dart';
import '../models/video_model.dart';
import 'trend_badge.dart';

/// A single full-screen video card in the vertical feed.
/// Shows the Trend badge if the video used an AI style filter.
class VideoCard extends StatelessWidget {
  final VideoModel video;
  final Widget videoPlayerWidget;

  const VideoCard({
    super.key,
    required this.video,
    required this.videoPlayerWidget,
  });

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: [
        // Video player fills the entire card
        videoPlayerWidget,

        // Trend badge (top-right)
        if (video.hasTrendBadge)
          Positioned(
            top: MediaQuery.of(context).padding.top + 12,
            right: 16,
            child: TrendBadge(styleName: video.styleFilter.styleName),
          ),

        // Bottom info overlay
        Positioned(
          left: 16,
          right: 80,
          bottom: 24,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              // Username
              Row(
                children: [
                  CircleAvatar(
                    radius: 16,
                    backgroundColor: Colors.white24,
                    backgroundImage: video.avatarUrl.isNotEmpty
                        ? NetworkImage(video.avatarUrl)
                        : null,
                    child: video.avatarUrl.isEmpty
                        ? const Icon(Icons.person, size: 18, color: Colors.white)
                        : null,
                  ),
                  const SizedBox(width: 8),
                  Text(
                    '@${video.username}',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w700,
                      fontSize: 15,
                      shadows: [Shadow(blurRadius: 4, color: Colors.black54)],
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              // Caption
              if (video.caption.isNotEmpty)
                Text(
                  video.caption,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 14,
                    shadows: [Shadow(blurRadius: 4, color: Colors.black54)],
                  ),
                ),
              const SizedBox(height: 6),
              // Tags
              if (video.tags.isNotEmpty)
                Wrap(
                  spacing: 6,
                  children: video.tags
                      .take(5)
                      .map((tag) => Text(
                            '#$tag',
                            style: const TextStyle(
                              color: Colors.white70,
                              fontSize: 13,
                              fontWeight: FontWeight.w600,
                            ),
                          ))
                      .toList(),
                ),
            ],
          ),
        ),

        // Right side action buttons
        Positioned(
          right: 12,
          bottom: 80,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              _actionButton(Icons.favorite, '${video.stats.likes}'),
              const SizedBox(height: 20),
              _actionButton(Icons.comment, '${video.stats.comments}'),
              const SizedBox(height: 20),
              _actionButton(Icons.share, '${video.stats.shares}'),
            ],
          ),
        ),
      ],
    );
  }

  Widget _actionButton(IconData icon, String label) {
    return Column(
      children: [
        Icon(icon, color: Colors.white, size: 32),
        const SizedBox(height: 4),
        Text(
          label,
          style: const TextStyle(color: Colors.white, fontSize: 12),
        ),
      ],
    );
  }
}
