import 'package:flutter/foundation.dart';
import '../models/style_filter_model.dart';
import '../filters/style_transfer_engine.dart';

/// Provider that manages the active AI style filter and exposes
/// the toggle state to the recording UI.
class StyleFilterProvider extends ChangeNotifier {
  final StyleTransferEngine _engine = StyleTransferEngine();

  List<StyleFilterModel> _availableStyles = StyleFilterModel.defaults;
  StyleFilterModel? _selectedStyle;
  bool _isProcessing = false;

  List<StyleFilterModel> get availableStyles => _availableStyles;
  StyleFilterModel? get selectedStyle => _selectedStyle;
  bool get isProcessing => _isProcessing;
  bool get isFilterActive => _selectedStyle != null;
  StyleTransferEngine get engine => _engine;

  void setAvailableStyles(List<StyleFilterModel> styles) {
    _availableStyles = styles;
    notifyListeners();
  }

  /// Called when user taps a style in the toggle carousel.
  Future<void> selectStyle(StyleFilterModel? style) async {
    if (style == null) {
      _engine.dispose();
      _selectedStyle = null;
      notifyListeners();
      return;
    }

    _isProcessing = true;
    notifyListeners();

    try {
      await _engine.switchStyle(style);
      _selectedStyle = style;
    } catch (e) {
      debugPrint('Failed to load style ${style.name}: $e');
      _selectedStyle = null;
    } finally {
      _isProcessing = false;
      notifyListeners();
    }
  }

  /// Quick toggle: cycle to the next style or turn off.
  Future<void> cycleNextStyle() async {
    if (_availableStyles.isEmpty) return;
    if (_selectedStyle == null) {
      await selectStyle(_availableStyles.first);
      return;
    }
    final currentIndex =
        _availableStyles.indexWhere((s) => s.name == _selectedStyle!.name);
    final nextIndex = (currentIndex + 1) % (_availableStyles.length + 1);
    if (nextIndex == _availableStyles.length) {
      await selectStyle(null); // turn off
    } else {
      await selectStyle(_availableStyles[nextIndex]);
    }
  }

  @override
  void dispose() {
    _engine.dispose();
    super.dispose();
  }
}
