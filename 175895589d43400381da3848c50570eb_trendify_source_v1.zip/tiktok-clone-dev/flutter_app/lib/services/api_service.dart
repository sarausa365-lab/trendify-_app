import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/video_model.dart';
import '../models/user_model.dart';
import '../models/style_filter_model.dart';

class ApiService {
  final String baseUrl;
  final http.Client _client;

  ApiService({required this.baseUrl, http.Client? client})
      : _client = client ?? http.Client();

  Map<String, String> _authHeaders(String token) => {
        'Authorization': 'Bearer $token',
        'Content-Type': 'application/json',
      };

  // ─── Auth ──────────────────────────────────────────────

  Future<AuthResponse> signup({
    required String username,
    required String email,
    required String password,
    String displayName = '',
  }) async {
    final response = await _client.post(
      Uri.parse('$baseUrl/api/auth/signup'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'username': username,
        'email': email,
        'password': password,
        'displayName': displayName,
      }),
    );
    if (response.statusCode != 201) {
      final body = json.decode(response.body);
      throw Exception(body['error'] ?? 'Signup failed');
    }
    final body = json.decode(response.body);
    return AuthResponse.fromJson(body['data']);
  }

  Future<AuthResponse> login({
    required String email,
    required String password,
  }) async {
    final response = await _client.post(
      Uri.parse('$baseUrl/api/auth/login'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({'email': email, 'password': password}),
    );
    if (response.statusCode != 200) {
      final body = json.decode(response.body);
      throw Exception(body['error'] ?? 'Login failed');
    }
    final body = json.decode(response.body);
    return AuthResponse.fromJson(body['data']);
  }

  Future<UserModel> getMe(String token) async {
    final response = await _client.get(
      Uri.parse('$baseUrl/api/auth/me'),
      headers: _authHeaders(token),
    );
    if (response.statusCode != 200) {
      throw Exception('Failed to fetch user');
    }
    final body = json.decode(response.body);
    return UserModel.fromJson(body['data']);
  }

  // ─── Profile ───────────────────────────────────────────

  Future<Map<String, dynamic>> getProfile(String token) async {
    final response = await _client.get(
      Uri.parse('$baseUrl/api/profile/me'),
      headers: _authHeaders(token),
    );
    if (response.statusCode != 200) {
      throw Exception('Failed to fetch profile');
    }
    return json.decode(response.body)['data'];
  }

  Future<List<VideoModel>> getMyVideos(String token,
      {bool trendOnly = false}) async {
    final query = trendOnly ? '?trend=true' : '';
    final response = await _client.get(
      Uri.parse('$baseUrl/api/profile/me/videos$query'),
      headers: _authHeaders(token),
    );
    if (response.statusCode != 200) {
      throw Exception('Failed to fetch videos');
    }
    final body = json.decode(response.body);
    final List<dynamic> items = body['data'] ?? [];
    return items.map((j) => VideoModel.fromJson(j)).toList();
  }

  // ─── Feed ──────────────────────────────────────────────

  Future<List<VideoModel>> getFeed({int page = 1, int limit = 20}) async {
    final response = await _client.get(
      Uri.parse('$baseUrl/api/feed?page=$page&limit=$limit'),
    );
    if (response.statusCode != 200) {
      throw Exception('Failed to load feed: ${response.statusCode}');
    }
    final body = json.decode(response.body);
    final List<dynamic> items = body['data'] ?? [];
    return items.map((j) => VideoModel.fromJson(j)).toList();
  }

  Future<List<VideoModel>> getTrending({int limit = 20}) async {
    final response = await _client.get(
      Uri.parse('$baseUrl/api/feed/trending?limit=$limit'),
    );
    if (response.statusCode != 200) {
      throw Exception('Failed to load trending: ${response.statusCode}');
    }
    final body = json.decode(response.body);
    final List<dynamic> items = body['data'] ?? [];
    return items.map((j) => VideoModel.fromJson(j)).toList();
  }

  // ─── Style Filters ────────────────────────────────────

  Future<List<StyleFilterModel>> getAvailableStyles() async {
    final response = await _client.get(
      Uri.parse('$baseUrl/api/styles'),
    );
    if (response.statusCode != 200) {
      throw Exception('Failed to load styles: ${response.statusCode}');
    }
    final body = json.decode(response.body);
    final List<dynamic> items = body['data'] ?? [];
    return items.map((j) => StyleFilterModel.fromJson(j)).toList();
  }

  // ─── Upload ────────────────────────────────────────────

  Future<VideoModel> uploadVideo({
    required String filePath,
    required String token,
    String caption = '',
    String tags = '',
    String styleName = 'none',
  }) async {
    final request = http.MultipartRequest(
      'POST',
      Uri.parse('$baseUrl/api/upload'),
    );
    request.headers['Authorization'] = 'Bearer $token';
    request.fields['caption'] = caption;
    request.fields['tags'] = tags;
    request.fields['styleName'] = styleName;
    request.files.add(await http.MultipartFile.fromPath('video', filePath));

    final streamedResponse = await request.send();
    final response = await http.Response.fromStream(streamedResponse);

    if (response.statusCode != 201) {
      throw Exception('Upload failed: ${response.body}');
    }

    final body = json.decode(response.body);
    return VideoModel.fromJson(body['data']);
  }

  void dispose() {
    _client.close();
  }
}
