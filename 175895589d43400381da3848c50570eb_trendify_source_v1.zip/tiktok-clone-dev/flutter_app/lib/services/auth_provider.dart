import 'package:flutter/foundation.dart';
import '../models/user_model.dart';

/// Manages authentication state across the app.
/// In the beta demo, supports mock login so testers can explore all screens.
class AuthProvider extends ChangeNotifier {
  String? _token;
  UserModel? _currentUser;
  bool _isLoading = false;
  String? _error;

  String? get token => _token;
  UserModel? get currentUser => _currentUser;
  bool get isAuthenticated => _token != null && _currentUser != null;
  bool get isLoading => _isLoading;
  String? get error => _error;

  /// Sign up with the Trendify backend.
  Future<bool> signup({
    required String username,
    required String email,
    required String password,
    String displayName = '',
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      // Real implementation calls ApiService.signup().
      // Beta mock: simulate success after a short delay.
      await Future.delayed(const Duration(milliseconds: 800));

      _currentUser = UserModel(
        id: 'beta_user_${DateTime.now().millisecondsSinceEpoch}',
        username: username.toLowerCase().trim(),
        email: email.toLowerCase().trim(),
        displayName: displayName.isNotEmpty ? displayName : username,
        createdAt: DateTime.now(),
      );
      _token = 'beta_jwt_mock_token_${_currentUser!.id}';

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  /// Log in with the Trendify backend.
  Future<bool> login({
    required String email,
    required String password,
  }) async {
    _isLoading = true;
    _error = null;
    notifyListeners();

    try {
      await Future.delayed(const Duration(milliseconds: 800));

      _currentUser = UserModel(
        id: 'beta_user_${DateTime.now().millisecondsSinceEpoch}',
        username: email.split('@').first,
        email: email.toLowerCase().trim(),
        displayName: email.split('@').first,
        bio: 'Trendify Beta Tester 🔥',
        createdAt: DateTime.now(),
      );
      _token = 'beta_jwt_mock_token_${_currentUser!.id}';

      _isLoading = false;
      notifyListeners();
      return true;
    } catch (e) {
      _error = e.toString();
      _isLoading = false;
      notifyListeners();
      return false;
    }
  }

  void logout() {
    _token = null;
    _currentUser = null;
    _error = null;
    notifyListeners();
  }

  void clearError() {
    _error = null;
    notifyListeners();
  }
}
