class UserModel {
  final String id;
  final String username;
  final String email;
  final String displayName;
  final String avatarUrl;
  final String bio;
  final int followers;
  final int following;
  final DateTime createdAt;

  UserModel({
    required this.id,
    required this.username,
    required this.email,
    this.displayName = '',
    this.avatarUrl = '',
    this.bio = '',
    this.followers = 0,
    this.following = 0,
    required this.createdAt,
  });

  factory UserModel.fromJson(Map<String, dynamic> json) {
    return UserModel(
      id: json['_id'] ?? json['id'] ?? '',
      username: json['username'] ?? '',
      email: json['email'] ?? '',
      displayName: json['displayName'] ?? json['username'] ?? '',
      avatarUrl: json['avatarUrl'] ?? '',
      bio: json['bio'] ?? '',
      followers: json['followers'] ?? 0,
      following: json['following'] ?? 0,
      createdAt: DateTime.tryParse(json['createdAt'] ?? '') ?? DateTime.now(),
    );
  }
}

class AuthResponse {
  final String token;
  final UserModel user;

  AuthResponse({required this.token, required this.user});

  factory AuthResponse.fromJson(Map<String, dynamic> json) {
    return AuthResponse(
      token: json['token'] ?? '',
      user: UserModel.fromJson(json['user'] ?? {}),
    );
  }
}

class ProfileStats {
  final int totalVideos;
  final int trendVideos;
  final int totalLikes;

  ProfileStats({
    this.totalVideos = 0,
    this.trendVideos = 0,
    this.totalLikes = 0,
  });

  factory ProfileStats.fromJson(Map<String, dynamic> json) {
    return ProfileStats(
      totalVideos: json['totalVideos'] ?? 0,
      trendVideos: json['trendVideos'] ?? 0,
      totalLikes: json['totalLikes'] ?? 0,
    );
  }
}
