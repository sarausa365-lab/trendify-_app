class StyleFilterModel {
  final String name;
  final String displayName;
  final String description;
  final String thumbnailUrl;
  final String modelFile;
  final bool isActive;
  final int usageCount;

  StyleFilterModel({
    required this.name,
    required this.displayName,
    this.description = '',
    this.thumbnailUrl = '',
    this.modelFile = '',
    this.isActive = true,
    this.usageCount = 0,
  });

  factory StyleFilterModel.fromJson(Map<String, dynamic> json) {
    return StyleFilterModel(
      name: json['name'] ?? '',
      displayName: json['displayName'] ?? json['name'] ?? '',
      description: json['description'] ?? '',
      thumbnailUrl: json['thumbnailUrl'] ?? '',
      modelFile: json['modelFile'] ?? json['modelFileName'] ?? '',
      isActive: json['isActive'] ?? true,
      usageCount: json['usageCount'] ?? 0,
    );
  }

  /// Hardcoded defaults when backend is unavailable
  static List<StyleFilterModel> get defaults => [
        StyleFilterModel(
          name: 'anime',
          displayName: 'Anime',
          description: 'Japanese anime art style with bold lines and vibrant colors',
          modelFile: 'anime_style_v1.tflite',
        ),
        StyleFilterModel(
          name: 'sketch',
          displayName: 'Sketch',
          description: 'Pencil sketch effect with detailed shading',
          modelFile: 'sketch_style_v1.tflite',
        ),
        StyleFilterModel(
          name: 'oil_painting',
          displayName: 'Oil Painting',
          description: 'Classic oil painting with rich textures and brush strokes',
          modelFile: 'oil_painting_style_v1.tflite',
        ),
        StyleFilterModel(
          name: 'watercolor',
          displayName: 'Watercolor',
          description: 'Soft watercolor painting with flowing color blends',
          modelFile: 'watercolor_style_v1.tflite',
        ),
        StyleFilterModel(
          name: 'pop_art',
          displayName: 'Pop Art',
          description: 'Bold pop art style inspired by Andy Warhol',
          modelFile: 'pop_art_style_v1.tflite',
        ),
      ];
}
