class StyleFilterMeta {
  final bool applied;
  final String styleName;
  final String modelVersion;
  final int processingTime;

  StyleFilterMeta({
    required this.applied,
    required this.styleName,
    this.modelVersion = '',
    this.processingTime = 0,
  });

  factory StyleFilterMeta.fromJson(Map<String, dynamic> json) {
    return StyleFilterMeta(
      applied: json['applied'] ?? false,
      styleName: json['styleName'] ?? 'none',
      modelVersion: json['modelVersion'] ?? '',
      processingTime: json['processingTime'] ?? 0,
    );
  }

  Map<String, dynamic> toJson() => {
        'applied': applied,
        'styleName': styleName,
        'modelVersion': modelVersion,
        'processingTime': processingTime,
      };
}

class VideoStats {
  final int views;
  final int likes;
  final int shares;
  final int comments;

  VideoStats({
    this.views = 0,
    this.likes = 0,
    this.shares = 0,
    this.comments = 0,
  });

  factory VideoStats.fromJson(Map<String, dynamic> json) {
    return VideoStats(
      views: json['views'] ?? 0,
      likes: json['likes'] ?? 0,
      shares: json['shares'] ?? 0,
      comments: json['comments'] ?? 0,
    );
  }
}

class VideoModel {
  final String id;
  final String userId;
  final String username;
  final String avatarUrl;
  final String videoUrl;
  final String thumbnailUrl;
  final String caption;
  final List<String> tags;
  final StyleFilterMeta styleFilter;
  final bool hasTrendBadge;
  final VideoStats stats;
  final double duration;
  final DateTime createdAt;

  VideoModel({
    required this.id,
    required this.userId,
    required this.username,
    this.avatarUrl = '',
    required this.videoUrl,
    this.thumbnailUrl = '',
    this.caption = '',
    this.tags = const [],
    required this.styleFilter,
    required this.hasTrendBadge,
    required this.stats,
    this.duration = 0,
    required this.createdAt,
  });

  factory VideoModel.fromJson(Map<String, dynamic> json) {
    final user = json['userId'];
    return VideoModel(
      id: json['_id'] ?? json['id'] ?? '',
      userId: user is Map ? (user['_id'] ?? '') : (user ?? ''),
      username: user is Map ? (user['username'] ?? 'unknown') : 'unknown',
      avatarUrl: user is Map ? (user['avatarUrl'] ?? '') : '',
      videoUrl: json['videoUrl'] ?? '',
      thumbnailUrl: json['thumbnailUrl'] ?? '',
      caption: json['caption'] ?? '',
      tags: List<String>.from(json['tags'] ?? []),
      styleFilter: StyleFilterMeta.fromJson(json['styleFilter'] ?? {}),
      hasTrendBadge: json['hasTrendBadge'] ?? false,
      stats: VideoStats.fromJson(json['stats'] ?? {}),
      duration: (json['duration'] ?? 0).toDouble(),
      createdAt: DateTime.tryParse(json['createdAt'] ?? '') ?? DateTime.now(),
    );
  }
}
