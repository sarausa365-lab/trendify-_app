import 'package:flutter/material.dart';
import '../../models/video_model.dart';
import '../../utils/trendify_theme.dart';
import '../../widgets/video_card.dart';

/// Full-screen vertical scrolling video feed (Trendify's "For You" page).
/// Uses PageView for snap scrolling between videos.
/// Videos with AI style filters display a "🔥 Trend" badge.
class FeedScreen extends StatefulWidget {
  final List<VideoModel> videos;
  final VoidCallback? onLoadMore;

  const FeedScreen({super.key, required this.videos, this.onLoadMore});

  @override
  State<FeedScreen> createState() => _FeedScreenState();
}

class _FeedScreenState extends State<FeedScreen> {
  late PageController _pageController;
  int _currentPage = 0;
  int _activeTab = 1; // 0 = Following, 1 = For You

  @override
  void initState() {
    super.initState();
    _pageController = PageController();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (widget.videos.isEmpty) {
      return Scaffold(
        backgroundColor: TrendifyBrand.dark,
        body: const Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.video_library_outlined, color: Colors.white24, size: 64),
              SizedBox(height: 16),
              Text('No videos yet',
                  style: TextStyle(color: Colors.white54, fontSize: 18)),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: TrendifyBrand.dark,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            GestureDetector(
              onTap: () => setState(() => _activeTab = 0),
              child: _tabLabel('Following', isActive: _activeTab == 0),
            ),
            const SizedBox(width: 8),
            Container(width: 1, height: 14, color: Colors.white24),
            const SizedBox(width: 8),
            GestureDetector(
              onTap: () => setState(() => _activeTab = 1),
              child: _tabLabel('For You', isActive: _activeTab == 1),
            ),
          ],
        ),
      ),
      body: PageView.builder(
        controller: _pageController,
        scrollDirection: Axis.vertical,
        itemCount: widget.videos.length,
        onPageChanged: (index) {
          setState(() => _currentPage = index);
          if (index >= widget.videos.length - 3) {
            widget.onLoadMore?.call();
          }
        },
        itemBuilder: (context, index) {
          final video = widget.videos[index];
          return VideoCard(
            video: video,
            videoPlayerWidget: _videoPlaceholder(video),
          );
        },
      ),
    );
  }

  Widget _tabLabel(String text, {required bool isActive}) {
    return Text(
      text,
      style: TextStyle(
        color: isActive ? Colors.white : Colors.white54,
        fontSize: 17,
        fontWeight: isActive ? FontWeight.w700 : FontWeight.w400,
      ),
    );
  }

  Widget _videoPlaceholder(VideoModel video) {
    return Container(
      color: TrendifyBrand.dark,
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            const Icon(Icons.play_circle_fill, color: Colors.white12, size: 80),
            const SizedBox(height: 8),
            Text(
              video.videoUrl.split('/').last,
              style: const TextStyle(color: Colors.white20, fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
