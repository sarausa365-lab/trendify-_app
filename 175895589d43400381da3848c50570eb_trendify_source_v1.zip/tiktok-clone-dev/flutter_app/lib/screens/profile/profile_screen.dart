import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/video_model.dart';
import '../../services/auth_provider.dart';
import '../../utils/trendify_theme.dart';
import '../../widgets/trend_badge.dart';

/// User profile page showing avatar, stats, and a grid of the user's
/// uploaded videos. A "Trend" tab filters to only videos that used an
/// AI Style Transfer filter.
class ProfileScreen extends StatefulWidget {
  const ProfileScreen({super.key});

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  bool _showTrendOnly = false;

  // Mock data — in production these come from ApiService
  final List<VideoModel> _userVideos = List.generate(
    12,
    (i) => VideoModel(
      id: 'profile_vid_$i',
      userId: 'me',
      username: 'me',
      videoUrl: 'https://example.com/my_video_$i.mp4',
      caption: i % 2 == 0
          ? 'My Trendify creation ✨'
          : 'Just having fun #trendify',
      tags: i % 2 == 0 ? ['trend', 'anime'] : ['fun'],
      styleFilter: StyleFilterMeta(
        applied: i % 2 == 0,
        styleName: i % 2 == 0
            ? ['anime', 'sketch', 'oil_painting', 'watercolor', 'pop_art'][i % 5]
            : 'none',
      ),
      hasTrendBadge: i % 2 == 0,
      stats: VideoStats(
        views: (i + 1) * 980,
        likes: (i + 1) * 320,
        shares: (i + 1) * 45,
        comments: (i + 1) * 22,
      ),
      createdAt: DateTime.now().subtract(Duration(days: i)),
    ),
  );

  List<VideoModel> get _filteredVideos => _showTrendOnly
      ? _userVideos.where((v) => v.hasTrendBadge).toList()
      : _userVideos;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _tabController.addListener(() {
      setState(() => _showTrendOnly = _tabController.index == 1);
    });
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final user = auth.currentUser;

    return Scaffold(
      backgroundColor: TrendifyBrand.dark,
      appBar: AppBar(
        title: Text(
          user?.username ?? 'Profile',
          style: const TextStyle(fontWeight: FontWeight.w700, fontSize: 18),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.logout, color: Colors.white70),
            onPressed: () => auth.logout(),
          ),
        ],
      ),
      body: NestedScrollView(
        headerSliverBuilder: (context, _) => [
          SliverToBoxAdapter(child: _buildProfileHeader(user)),
          SliverPersistentHeader(
            pinned: true,
            delegate: _TabBarDelegate(
              TabBar(
                controller: _tabController,
                indicatorColor: TrendifyBrand.primary,
                labelColor: Colors.white,
                unselectedLabelColor: Colors.white54,
                tabs: const [
                  Tab(icon: Icon(Icons.grid_on)),
                  Tab(icon: Icon(Icons.local_fire_department)),
                ],
              ),
            ),
          ),
        ],
        body: _buildVideoGrid(),
      ),
    );
  }

  Widget _buildProfileHeader(dynamic user) {
    final trendCount = _userVideos.where((v) => v.hasTrendBadge).length;
    final totalLikes =
        _userVideos.fold<int>(0, (sum, v) => sum + v.stats.likes);

    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 16),
      child: Column(
        children: [
          // Avatar
          Container(
            width: 86,
            height: 86,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              gradient: TrendifyBrand.logoGradient,
            ),
            padding: const EdgeInsets.all(3),
            child: CircleAvatar(
              radius: 40,
              backgroundColor: TrendifyBrand.surface,
              child: Text(
                (user?.displayName ?? 'T')[0].toUpperCase(),
                style: const TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.w700,
                    color: Colors.white),
              ),
            ),
          ),
          const SizedBox(height: 12),
          Text(
            '@${user?.username ?? 'trendify_user'}',
            style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w700,
                color: Colors.white),
          ),
          const SizedBox(height: 4),
          Text(
            user?.bio ?? 'Trendify Beta Tester 🔥',
            style: const TextStyle(
                fontSize: 13, color: TrendifyBrand.textSecondary),
          ),
          const SizedBox(height: 18),

          // Stats row
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              _statColumn('${_userVideos.length}', 'Videos'),
              _statColumn('$trendCount', '🔥 Trends'),
              _statColumn(_formatCount(totalLikes), 'Likes'),
              _statColumn('0', 'Followers'),
            ],
          ),
          const SizedBox(height: 16),

          // Edit profile button
          SizedBox(
            width: double.infinity,
            child: OutlinedButton(
              onPressed: () {},
              style: OutlinedButton.styleFrom(
                side: const BorderSide(color: Colors.white24),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8)),
              ),
              child: const Text('Edit Profile',
                  style: TextStyle(color: Colors.white)),
            ),
          ),
        ],
      ),
    );
  }

  Widget _statColumn(String count, String label) {
    return Column(
      children: [
        Text(count,
            style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.w700,
                color: Colors.white)),
        const SizedBox(height: 2),
        Text(label,
            style: const TextStyle(
                fontSize: 12, color: TrendifyBrand.textSecondary)),
      ],
    );
  }

  Widget _buildVideoGrid() {
    final videos = _filteredVideos;
    if (videos.isEmpty) {
      return Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              _showTrendOnly
                  ? Icons.local_fire_department
                  : Icons.video_library_outlined,
              color: Colors.white24,
              size: 56,
            ),
            const SizedBox(height: 12),
            Text(
              _showTrendOnly
                  ? 'No Trend videos yet\nUse a style filter to create one!'
                  : 'No videos yet',
              textAlign: TextAlign.center,
              style:
                  const TextStyle(color: TrendifyBrand.textSecondary, fontSize: 14),
            ),
          ],
        ),
      );
    }

    return GridView.builder(
      padding: const EdgeInsets.all(2),
      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: 3,
        childAspectRatio: 9 / 16,
        crossAxisSpacing: 2,
        mainAxisSpacing: 2,
      ),
      itemCount: videos.length,
      itemBuilder: (context, index) {
        final video = videos[index];
        return _videoThumbnail(video);
      },
    );
  }

  Widget _videoThumbnail(VideoModel video) {
    return Stack(
      fit: StackFit.expand,
      children: [
        Container(
          color: TrendifyBrand.surface,
          child: const Center(
            child:
                Icon(Icons.play_arrow_rounded, color: Colors.white24, size: 36),
          ),
        ),
        // Trend badge overlay
        if (video.hasTrendBadge)
          Positioned(
            top: 6,
            left: 6,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
              decoration: BoxDecoration(
                gradient: TrendifyBrand.trendGradient,
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Text('🔥',
                  style: TextStyle(fontSize: 10)),
            ),
          ),
        // View count
        Positioned(
          bottom: 6,
          left: 6,
          child: Row(
            children: [
              const Icon(Icons.play_arrow, color: Colors.white70, size: 14),
              const SizedBox(width: 2),
              Text(
                _formatCount(video.stats.views),
                style: const TextStyle(color: Colors.white70, fontSize: 11),
              ),
            ],
          ),
        ),
      ],
    );
  }

  String _formatCount(int count) {
    if (count >= 1000000) return '${(count / 1000000).toStringAsFixed(1)}M';
    if (count >= 1000) return '${(count / 1000).toStringAsFixed(1)}K';
    return '$count';
  }
}

class _TabBarDelegate extends SliverPersistentHeaderDelegate {
  final TabBar tabBar;
  _TabBarDelegate(this.tabBar);

  @override
  double get minExtent => tabBar.preferredSize.height;
  @override
  double get maxExtent => tabBar.preferredSize.height;

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    return Container(color: TrendifyBrand.dark, child: tabBar);
  }

  @override
  bool shouldRebuild(covariant _TabBarDelegate oldDelegate) => false;
}
