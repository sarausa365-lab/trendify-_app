import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../services/style_filter_provider.dart';
import '../../widgets/style_toggle_carousel.dart';

/// Camera recording screen with real-time AI Style Transfer preview.
///
/// The style toggle carousel at the bottom lets users switch between
/// Anime, Sketch, Oil Painting, Watercolor, and Pop Art styles in
/// real-time before/during recording.
class RecordScreen extends StatefulWidget {
  const RecordScreen({super.key});

  @override
  State<RecordScreen> createState() => _RecordScreenState();
}

class _RecordScreenState extends State<RecordScreen> {
  bool _isRecording = false;
  bool _showStylePicker = true;

  @override
  Widget build(BuildContext context) {
    return Consumer<StyleFilterProvider>(
      builder: (context, filterProvider, child) {
        return Scaffold(
          backgroundColor: Colors.black,
          body: Stack(
            fit: StackFit.expand,
            children: [
              // Camera preview area (placeholder)
              _cameraPreviewPlaceholder(filterProvider),

              // Top bar
              Positioned(
                top: MediaQuery.of(context).padding.top + 8,
                left: 16,
                right: 16,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    IconButton(
                      icon: const Icon(Icons.close, color: Colors.white, size: 28),
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                    if (filterProvider.isFilterActive)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 6),
                        decoration: BoxDecoration(
                          color: const Color(0xFFFF2D55).withOpacity(0.8),
                          borderRadius: BorderRadius.circular(16),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.auto_awesome,
                                color: Colors.white, size: 16),
                            const SizedBox(width: 4),
                            Text(
                              filterProvider.selectedStyle!.displayName,
                              style: const TextStyle(
                                color: Colors.white,
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    IconButton(
                      icon: const Icon(Icons.flip_camera_ios,
                          color: Colors.white, size: 28),
                      onPressed: () {
                        // Toggle front/back camera
                      },
                    ),
                  ],
                ),
              ),

              // Right-side tools
              Positioned(
                right: 12,
                top: MediaQuery.of(context).size.height * 0.3,
                child: Column(
                  children: [
                    _toolButton(
                      Icons.auto_awesome,
                      'Styles',
                      isActive: _showStylePicker,
                      onTap: () =>
                          setState(() => _showStylePicker = !_showStylePicker),
                    ),
                    const SizedBox(height: 20),
                    _toolButton(Icons.speed, 'Speed', onTap: () {}),
                    const SizedBox(height: 20),
                    _toolButton(Icons.timer, 'Timer', onTap: () {}),
                    const SizedBox(height: 20),
                    _toolButton(Icons.flash_on, 'Flash', onTap: () {}),
                  ],
                ),
              ),

              // AI Style Toggle Carousel (bottom)
              if (_showStylePicker)
                Positioned(
                  left: 0,
                  right: 0,
                  bottom: 140,
                  child: StyleToggleCarousel(
                    styles: filterProvider.availableStyles,
                    activeStyleName: filterProvider.selectedStyle?.name,
                    isLoading: filterProvider.isProcessing,
                    onStyleSelected: (style) =>
                        filterProvider.selectStyle(style),
                  ),
                ),

              // Record button
              Positioned(
                bottom: 40,
                left: 0,
                right: 0,
                child: Center(
                  child: GestureDetector(
                    onTap: _toggleRecording,
                    child: AnimatedContainer(
                      duration: const Duration(milliseconds: 200),
                      width: _isRecording ? 64 : 76,
                      height: _isRecording ? 64 : 76,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(color: Colors.white, width: 4),
                      ),
                      child: Center(
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          width: _isRecording ? 28 : 60,
                          height: _isRecording ? 28 : 60,
                          decoration: BoxDecoration(
                            color: const Color(0xFFFF2D55),
                            borderRadius: BorderRadius.circular(
                                _isRecording ? 6 : 30),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _cameraPreviewPlaceholder(StyleFilterProvider filterProvider) {
    return Container(
      color: Colors.grey[900],
      child: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              filterProvider.isFilterActive
                  ? Icons.auto_awesome
                  : Icons.videocam,
              color: Colors.white24,
              size: 64,
            ),
            const SizedBox(height: 12),
            Text(
              filterProvider.isFilterActive
                  ? 'Camera Preview with ${filterProvider.selectedStyle!.displayName} filter'
                  : 'Camera Preview',
              style: const TextStyle(color: Colors.white38, fontSize: 14),
            ),
            if (_isRecording)
              const Padding(
                padding: EdgeInsets.only(top: 12),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Icon(Icons.fiber_manual_record,
                        color: Colors.red, size: 12),
                    SizedBox(width: 6),
                    Text('Recording...',
                        style: TextStyle(color: Colors.red, fontSize: 13)),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _toolButton(IconData icon, String label,
      {bool isActive = false, required VoidCallback onTap}) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        children: [
          Container(
            width: 40,
            height: 40,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: isActive
                  ? const Color(0xFFFF2D55).withOpacity(0.6)
                  : Colors.white.withOpacity(0.1),
            ),
            child: Icon(icon, color: Colors.white, size: 22),
          ),
          const SizedBox(height: 4),
          Text(label,
              style: const TextStyle(color: Colors.white70, fontSize: 10)),
        ],
      ),
    );
  }

  void _toggleRecording() {
    setState(() => _isRecording = !_isRecording);
  }
}
