import 'package:flutter/material.dart';

/// Trendify brand constants and theme used across every screen.
class TrendifyBrand {
  TrendifyBrand._();

  static const String appName = 'Trendify';
  static const String tagline = 'Set the Trend 🔥';

  // Brand colors
  static const Color primary = Color(0xFFFF2D55);
  static const Color secondary = Color(0xFF00F2EA);
  static const Color accent = Color(0xFFFF6B35);
  static const Color dark = Color(0xFF0D0D0D);
  static const Color surface = Color(0xFF1A1A1A);
  static const Color textPrimary = Colors.white;
  static const Color textSecondary = Color(0xFFAAAAAA);

  static const LinearGradient logoGradient = LinearGradient(
    colors: [secondary, primary],
  );

  static const LinearGradient trendGradient = LinearGradient(
    colors: [primary, accent],
  );

  static ThemeData get theme => ThemeData.dark().copyWith(
        scaffoldBackgroundColor: dark,
        colorScheme: const ColorScheme.dark(
          primary: primary,
          secondary: secondary,
          surface: surface,
        ),
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
          centerTitle: true,
        ),
        elevatedButtonTheme: ElevatedButtonThemeData(
          style: ElevatedButton.styleFrom(
            backgroundColor: primary,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 16),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            textStyle:
                const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
          ),
        ),
        inputDecorationTheme: InputDecorationTheme(
          filled: true,
          fillColor: surface,
          hintStyle: const TextStyle(color: textSecondary),
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide.none,
          ),
          contentPadding:
              const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        ),
      );
}

/// Reusable Trendify logo widget used in splash, auth, and profile screens.
class TrendifyLogo extends StatelessWidget {
  final double size;
  final bool showTagline;

  const TrendifyLogo({super.key, this.size = 40, this.showTagline = false});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        // Stylized icon mark
        Container(
          width: size * 1.5,
          height: size * 1.5,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: TrendifyBrand.logoGradient,
            boxShadow: [
              BoxShadow(
                color: TrendifyBrand.primary.withOpacity(0.4),
                blurRadius: size * 0.4,
                spreadRadius: size * 0.05,
              ),
            ],
          ),
          child: Icon(Icons.local_fire_department_rounded,
              color: Colors.white, size: size * 0.8),
        ),
        SizedBox(height: size * 0.3),
        ShaderMask(
          shaderCallback: (bounds) =>
              TrendifyBrand.logoGradient.createShader(bounds),
          child: Text(
            TrendifyBrand.appName,
            style: TextStyle(
              fontSize: size * 0.8,
              fontWeight: FontWeight.w900,
              color: Colors.white,
              letterSpacing: 1.5,
            ),
          ),
        ),
        if (showTagline) ...[
          SizedBox(height: size * 0.15),
          Text(
            TrendifyBrand.tagline,
            style: TextStyle(
              fontSize: size * 0.35,
              color: TrendifyBrand.textSecondary,
            ),
          ),
        ],
      ],
    );
  }
}
